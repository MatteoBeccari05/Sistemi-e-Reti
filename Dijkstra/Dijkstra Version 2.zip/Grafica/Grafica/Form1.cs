﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grafica
{
    public partial class Form1 : Form
    {
        Graphics foglio;
        Pen penna;
        int raggio;
        bool disegnaVertice;
        List<Point> centro;
        public Form1()
        {
            InitializeComponent();
            penna = new Pen(Color.Blue, 5);
            raggio = 10;
            centro = new List<Point>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foglio = e.Graphics;
            if (disegnaVertice)
            {
                if (centro.Contains(Location))
                {
                    MessageBox.Show("Impossibile disegnare qui");
                }
                else
                {
                    foreach (Point d in centro)
                    {
                        foglio.DrawEllipse(penna, d.X, d.Y, 1, 1);
                        foglio.DrawEllipse(penna, d.X - raggio, d.Y - raggio, raggio * 2, raggio * 2);
                        
                    }
                }
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            centro.Add(e.Location);
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            disegnaVertice = true;
            this.Invalidate();
        }
    }
}
