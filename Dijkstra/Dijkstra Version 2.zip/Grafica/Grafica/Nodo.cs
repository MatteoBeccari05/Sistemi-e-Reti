﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafica
{
    class Nodo
    {
        static int indice;
        string nome;
        List<Arco> archi;
        List<Linea> camminoMinimo;
        public Nodo()
        {
            archi = new List<Arco>();
            indice++;
            nome = indice.ToString();
        }
        public Nodo(string nome) : this()
        {
            this.nome += nome;
        }

        public string Nome { get => nome; }
        internal List<Arco> Archi { get => archi; }
        internal List<Linea> CamminoMinimo()
        {
            Grafo g = new Grafo(this);

            return camminoMinimo;
        }
    }
}
