﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafica
{
    class Grafo
    {
        List<Nodo> nodi;
        public Grafo(Nodo n)
        {
            nodi = new List<Nodo>();
            nodi.Add(n);
            for (int i = 0; i < nodi.Count; i++)
            {
                foreach (Arco a in nodi[i].Archi)
                {
                    if (nodi.Find(x => x.Nome.Equals(a.Destinazione.Nome)) is null)
                    {
                        nodi.Add(a.Destinazione);
                    }   
                }      
            }     
        }
        public List<Linea> CamminoMinimo()
        {
            List<Linea> finale = new List<Linea>();
            List<Linea> indagine = new List<Linea>();
            foreach (Nodo nodo in nodi)
                indagine.Add(new Linea(nodo.Nome, "", int.MaxValue));
            indagine[0].Costo = 0;//da far uscire il costo
            return new List<Linea>();
        }
    }
}
