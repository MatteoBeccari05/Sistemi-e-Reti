﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafica
{
    class Linea
    {
        string da, a;
        int costo;
        public Linea(string da, string a, int costo)
        {
            this.da = da;
            this.a = a;
            this.costo = costo;
        }

        public int Costo { get => costo; set => costo = value; }
    }
}
