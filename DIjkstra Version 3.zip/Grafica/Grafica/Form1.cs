﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grafica
{
    public partial class Form1 : Form
    {
        Nodo n;
        Graphics foglio;
        Pen penna;
        int raggio;
        bool disegnaVertice;
        int verticiTotali;
        List<Point> centro;
        public Form1()
        {
            InitializeComponent();
            penna = new Pen(Color.Blue, 5);
            raggio = 10;
            centro = new List<Point>();
            n = new Nodo();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int nomeVertici = 0;
            foglio = e.Graphics;
            if (disegnaVertice)
            {
                if (centro.Contains(Location))
                {
                    MessageBox.Show("Impossibile disegnare qui");
                }
                else
                {
                    verticiTotali++;
                    nomeVertici++;
                    foreach (Point d in centro)
                    {
                        foglio.DrawEllipse(penna, d.X, d.Y, 1, 1);
                        foglio.DrawEllipse(penna, d.X - raggio, d.Y - raggio, raggio * 2, raggio * 2);
                        lblX.Text = Convert.ToString(d.X);
                        lblY.Text = Convert.ToString(d.Y);
                        lblVerticiTot.Text = Convert.ToString(verticiTotali);
                        foglio.DrawString("Nodo " + Convert.ToString(nomeVertici++), new Font("arial", 10), new SolidBrush(Color.Black), new Point(d.X, d.Y+10));
                    }
                    
                    /*for (int i = 0; i < centro.Count; i++)
                    {
                        e.Graphics.DrawLine(penna, centro[i], centro[i + 1]);
                    }*/

                }
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            centro.Add(e.Location);
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            disegnaVertice = true;
            this.Invalidate();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

    }
}
