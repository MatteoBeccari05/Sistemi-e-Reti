﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafica
{
    class Arco
    {
        int costo;
        Nodo destinazione;
        public Nodo Destinazione { get => destinazione; }
        public int Costo { get => costo; set => costo = value; }
    }
}
