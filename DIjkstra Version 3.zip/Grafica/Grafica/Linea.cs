﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafica
{
    class Linea
    {
        string _inizio, _fine;
        int costo;

        public Linea(string inizio, string fine, int costo)
        {
            _inizio = inizio;
            _fine = fine;
            Costo = costo;
            
        }

        public int Costo { get => costo; set => costo = value; }
    }
}
